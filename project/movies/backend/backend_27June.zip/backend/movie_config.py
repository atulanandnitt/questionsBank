# config.py contains configuration

mysql_creds = {
'host':'localhost',
'user':'root',
'password':'root123',
'db':'moviedb',
'charset':'utf8'
}

# API keys

# Other Global variables
